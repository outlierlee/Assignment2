import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.*;
import org.jsoup.nodes.Document;
public class Liujunjie2014302580245 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Document doc=Jsoup.connect("http://staff.whu.edu.cn/show.jsp?lang=cn&n=Feng%20Jun").get();
		FileWriter writer=new FileWriter("result.txt");
		String allmessage="";
		String name=doc.select("h1[class]").first().text();
		allmessage+="������ "+name+" ";
		String messages=doc.select("p").first().text();
		Pattern telephone=Pattern.compile("\\d{3}-\\d{8}");
		Pattern email=Pattern.compile("\\w+@(\\w+.)+\\w+");
		Pattern synopsis=Pattern.compile("[\u4e00-\u9fa5]+");
		Matcher m1=telephone.matcher(messages);
		Matcher m2=email.matcher(messages);
		Matcher m3=synopsis.matcher(messages);
		allmessage+="��飺";
		while(m3.find()){
			allmessage+=m3.group()+" ";
		}
		while(m1.find()){
			allmessage+="��"+m1.group()+" ";
		}
		allmessage+="���� �� ";
		while(m2.find()){
			allmessage+=m2.group();
		}
		writer.write(allmessage);
		writer.flush();
		writer.close();
	}

}
