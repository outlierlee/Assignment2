import org.jsoup.*;
import org.jsoup.nodes.Document;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class llw2014302580246 {
	public static void main(String[] args) throws IOException
	{
		llw2014302580246 a=new llw2014302580246();
		a.out("a.HTML");
	}
	private void out(String filename) throws IOException
	{
		String str="";
		File input= new File(filename);
		Document doc=Jsoup.parse(input,"UTF-8","");
		String name=doc.select("h3").first().text();
		str+=name;
		System.out.println(name);
		String str1=doc.select("p").first().text();
		Pattern a = Pattern.compile("\\w+@(\\w+.)+\\w+");
		Pattern b =Pattern.compile("\\d{11}");
		Matcher matcher1 = a.matcher(str1);
		while(matcher1.find()){
			System.out.println(matcher1.group());
			str+=matcher1.group();
		}
		Matcher matcher2=b.matcher(str1);
		while(matcher2.find()){
			System.out.println(matcher2.group());
			str+=matcher2.group();
		}
		 FileWriter fileWriter=new FileWriter("assignment2.txt");
		 fileWriter.write(str);
		 fileWriter.flush();
		 fileWriter.close();
		
	}
	

}
